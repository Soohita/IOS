//
//  getLine.h
//  draw1a
//
//  Created by KimSoo Ha on 2017-04-17.
//  Copyright © 2017 KimSoo Ha. All rights reserved.
//

#ifndef getLine_h
#define getLine_h

#include <stdio.h>
int getwords(char *line, char *words[], int maxwords);

#endif /* getLine_h */
