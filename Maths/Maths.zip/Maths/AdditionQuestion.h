//
//  AdditionQuestion.h
//  Maths
//
//  Created by Matheus Dussin Bampi on 2017-04-19.
//  Copyright © 2017 Matheus Dussin Bampi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdditionQuestion : NSObject

@property NSString * question;
@property NSInteger answer;

- (instancetype)init;

    
@end
