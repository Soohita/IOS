//
//  InputHandler.h
//  Maths
//
//  Created by Matheus Dussin Bampi on 2017-04-20.
//  Copyright © 2017 Matheus Dussin Bampi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InputHandler : NSObject

@property NSString * string;

- (instancetype)init;

@end
